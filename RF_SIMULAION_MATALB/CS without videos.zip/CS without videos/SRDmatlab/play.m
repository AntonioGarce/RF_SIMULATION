data3 = (r)';
mean(data3)
meanfreq(data3)
median(data3)
pd = fitdist(data3,'Normal')
m = mean(pd)

x_pdf = [1:0.1:100];
y = pdf(pd,x_pdf);