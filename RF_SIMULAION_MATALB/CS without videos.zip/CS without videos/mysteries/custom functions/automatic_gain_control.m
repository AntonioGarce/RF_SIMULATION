%% Automatic Gain Control 
% This function is derived from agcvsfading.m from SRD Book code
% ds,mu are the voodoo parameter and must be configured with care 

function s = automatic_gain_control(r,mu,ds)
    n = length(r);                     
    a=zeros(1,n); a(1)=0;              % initialize AGC parameter
    s=zeros(1,n);                      % initialize outputs       
    for k=1:n-1
        s(k)=a(k)*r(k);                % normalize by a(k) to get s[k]
        a(k+1)=a(k)-mu*(s(k)^2-ds);    % adaptive update of a(k)
    end
return 