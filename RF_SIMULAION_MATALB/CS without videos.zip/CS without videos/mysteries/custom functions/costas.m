%% COSTAS LOOP 
% This function is derived from costasloop.m from SRD Book code
% mu is the voodoo parameter and must be configured with care 

function estimation_coefficients = costas(r,Ts,f0,mu)
    time = length(r)*Ts;        
    t=0:Ts:time-Ts;                                            % Initialize time vector  
    estimation_coefficients=zeros(1,length(r));                % Initialize carrier estimate vector
    fl=100; ff=[0 .01 .02 1]; fa=[1 1 0 0];
    h=firpm(fl,ff,fa);                                         % LPF design
    theta=zeros(1,length(t)); theta(1)=0;                      % initialize estimate vector
    zs=zeros(1,fl+1); zc=zeros(1,fl+1);                        % initialize buffers for LPFs
    for k=1:length(t)-1                                        % z's contain past fl+1 inputs
        zs=[zs(2:fl+1), 2*r(k)*sin(2*pi*f0*t(k)+theta(k))];
        zc=[zc(2:fl+1), 2*r(k)*cos(2*pi*f0*t(k)+theta(k))];
        lpfs=fliplr(h)*zs'; lpfc=fliplr(h)*zc';                % new output of filters
        theta(k+1)=theta(k)-mu*lpfs*lpfc;                      % algorithm update
        estimation_coefficients(k)=cos(2*pi*f0*t(k)+theta(k)); % Storing Carrier estimations
    end
    figure(2), plot(t,theta),                                             % plotting theta against time
    title('Phase Tracking via the Costas Loop') 
    xlabel('time'); ylabel('phase offset')
return

