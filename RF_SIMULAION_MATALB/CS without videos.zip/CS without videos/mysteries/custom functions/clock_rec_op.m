%% Power optimization time recovery algorithm 
% This function is derived from clockrecOP.m from SRD Book code
% mu is the voodoo parameter and must be configured with care 
% clockrecOP.m:  clock recovery maximizing output power
% find tau to optimize J(tau)=|x(kT/m+tau)|^2
% mu and delta are voodoo params to be configured carefully.

function xs = clock_rec_op(x, m, l, mu, delta)
    n = round(length(x)/m);
    tnow=l*m+1; tau=0; xs=zeros(1,n);           % initialize variables
    tausave=zeros(1,n); tausave(1)=tau; i=0;
    % run clock recovery algorithm
    while tnow<length(x)-l*m                    % run iteration
        i=i+1;
        xs(i)=interpsinc(x,tnow+tau,l);           % interpolated value at tnow+tau
        x_deltap=interpsinc(x,tnow+tau+delta,l);  % get value to the right
        x_deltam=interpsinc(x,tnow+tau-delta,l);  % get value to the left
        dx=x_deltap-x_deltam;                     % calculate numerical derivative
        tau=tau+mu*dx*xs(i);                      % alg update (energy)
        tnow=tnow+m; tausave(i)=tau;              % save for plotting
    end
 return




