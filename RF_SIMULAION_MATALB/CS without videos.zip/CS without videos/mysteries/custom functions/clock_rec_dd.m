%% Decision directive time recovery algorithm 
% This function is derived from clockrecDD.m from SRD Book code
% mu and delta are the voodoo parameter and must be configured with care
function xs = clock_rec_dd(x, m, l, mu, delta)
n = round(length(x)/m);
tnow=l*m+1; tau=0; xs=zeros(1,n);                   % initialize variables
    tausave=zeros(1,n); tausave(1)=tau; i=0;        % time for derivative
        while tnow<length(x)-2*l*m                  % run iteration
          i=i+1;
          xs(i)=interpsinc(x,tnow+tau,l);           % interpolated value at tnow+tau
          x_deltap=interpsinc(x,tnow+tau+delta,l);  % get value to the right
          x_deltam=interpsinc(x,tnow+tau-delta,l);  % get value to the left
          dx=x_deltap-x_deltam;                     % calculate numerical derivative
          qx=quantalph(xs(i),[-3,-1,1,3]);          % quantize xs to nearest 4-PAM symbol
          tau=tau+mu*dx*(qx-xs(i));                 % alg update: DD
          tnow=tnow+m; tausave(i)=tau;              % save for plotting
        end
return