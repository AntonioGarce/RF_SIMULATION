clc, clear, close all
%    mysteryA:  SRRCLength:     6
%               SRRCrolloff:    0.2
%               T_t:            7.5e-6 s
%               f_if:           2.3 MHz
%               f_s:            840 kHz 
% 
%    mysteryB:  SRRCLength:     3
%               SRRCrolloff:    0.4
%               T_t:            9.7e-6 s
%               f_if:           1.68 MHz
%               f_s:            740 kHz

%    mysteryC:  SRRCLength:     4
%               SRRCrolloff:    0.37
%               T_t:            6.25e-6 s
%               f_if:           2.1 MHz
%               f_s:            920 kHz



str = input('Input the name of mystery.(ex.A for mysteryA):','s');

strMystery = append('mystery',str,'.mat');
strTfParams = append('mystery',str,'_tf_params.mat');

if(isfile(strMystery)==0 || isfile(strTfParams)==0)
    f = msgbox('File is not exist.');
    return;
end

load(strMystery);
load(strTfParams);

Ts = 1/f_s;                             % sampling time 

% plot the received signal
figure(1), plotspec(r, Ts), 
title('Received  signal')

%% DownConversion with carrier recovery

f0 = abs(f_if-round(f_if/f_s)*f_s);     %frequency to be downconverted ie. min|f_if-n*f_s|                    

% preprocess for pll
rsc=r; 
fs = f_s;
interp = false;         %flag for interplation

%if twice of nominal frequency is above half of the sampling frequency you should interpolate twice
if fs<4*f0    
    interp = true;      
    N= length(r);       %length of received signal
    rsc=zeros(1,N*2);    
    rsc(1:2:N*2)=r;     %received signal which is upsampled twice
    fs=2*fs;
end   
    
q=rsc.^2;               % squared signal

fcq = 4*f0/fs;         %center frequency of squared signal which is used to design bp filter

fwdcut = 0.04;          

fl=100; ff=[0 fcq-fwdcut fcq-fwdcut/2 fcq+fwdcut/2 fcq+fwdcut 1]; 
fa=[0 0 1 1 0 0];                  
h=firpm(fl,ff,fa);                 % BPF design via firpm
r_sq=filtfilt(h,1,q);                  % filter to give preprocessed r

% pllgeneral algorithm to get carrier
t=1/fs:1/fs:length(rsc)/fs;

mu=.003; % algorithm stepsize
a=[1 -1]; lena=length(a)-1; % autoregressive terms
b=[-2 2-mu ] ; lenb=length(b); % moving average terms
xvec=zeros(lena ,1); % initialize filters
evec=zeros(lenb ,1);

theta=zeros(1 ,length( t )); theta (1)=0; %initialize estimates
for k=1:length(t)-1
    e=r_sq( k )*sin(4*pi*f0*t(k)+2*theta(k)); % input to f ilt e r
    evec=[e ; evec(1:lenb-1)]; % past values of inputs
    x=-a(2:lena+1)*xvec+b*evec ; % output of f ilt e r
    xvec=[x ; xvec(1: lena-1,1)]; % past values of outputs
    theta (k+1)=theta (k)+mu*x; % algorithm update
    carrier(k)=cos(2*pi*f0*t(k)+theta(k));
end

if interp == true
    carrier=carrier(1:2:length(carrier));  %downsampling
end
figure(11)
plot(t,theta);
xlabel('time[s]');
ylabel('\theta[rad]');
carrier=carrier';

r_b = r .* carrier/2;                   % Demodulate the signal using carrier

figure(2), plotspec(carrier, Ts),   
title('recovered Carrier Signal')

figure(3), plotspec(r_b, Ts)
title('Baseband signal before LPF')

fp = 2*f0/f_s;                          %pass frequency of lowpass filter which is used to get baseband signal
fst = fp+0.1;                           %stop frequency of lowpass filter which is used to get baseband signal

h = firpm(50,[0 fp fst 1],[1 1 0 0]);   % LPF filter to get baseband signal           

r_b = filtfilt(h, 1, r_b);              % implement LPF 

figure(4), plot((1:length(h))*f_s/2*length(h)-f_s/2,abs(fftshift(fft(h))));
title('Frequency response of LPF')

figure(5);
plotspec(r_b, Ts);
title('baseband signal after LPF');
title('LPF filter');

%% matched filter

M = f_s*T_t;   
matchfilt = srrc(SRRCLen, beta, M, 0);          % get srrc filter as matched filter
r_mt = filtfilt(matchfilt, 1, r_b);             % implement the matched filter

figure(6);
subplot(2,1,1);
plot(r_b)                                                            
title('received signal before Matched filter')
subplot(2,1,2);
plot(r_mt)                                                            
title('received signal after Matched filter')


%% interpolation/downsampler with timing recovery
          
len = length(r);                                        % Length of the received Signal                      
r_tim = zeros(1,ceil(len/M));                           % initialize down smapled signal 
l = SRRCLen;

% timing-recovery algorithm using the recursive output-power-maximization algorithm
tnow = l*M+1; tau=0;                                    % initialized Variables
tausave = zeros(1,len); tausave(1)=tau; i=0;                            
mu = 0.05;                                              % algorithm stepsize
delta = 0.1;                                            % time for derivate

while tnow < len-l*M                                    % run iteration
  i=i+1;
  r_tim(i) = interpsinc(r_mt, tnow+tau, l);             % interpolated value at tnow+tau
  x_deltap = interpsinc(r_mt, tnow+tau+delta, l);       % value to right
  x_deltam = interpsinc(r_mt, tnow+tau-delta, l);       % value to left
  dx = x_deltap - x_deltam;                             % numerical derivative                      % alg update
  tau = tau + mu*dx*r_tim(i);                           % alg update (energy)
  tnow = tnow + M; 
  tausave(i)=tau;                                       % save for plotting
end

% plot results
figure(7), subplot(2,1,1), plot(r_tim(1:i-2),'b.')        
title('Constellation diagram');
ylabel('Estimated Symbols')
subplot(2,1,2), plot(tausave(1:i-2))                      
ylabel('off_set estimates'), xlabel('iterations')

%% Training segmentation locater and Equalizer

%training sementation locator
preamble = 'A0Oh well whatever Nevermind';                     % preamble letters used as training data for equalizer
preamble_code = letters2pam(preamble);                         % 4-pam code for preamble

preamble_len = length(preamble_code);                          % length of preamble code

thres = sum(preamble_code.*preamble_code)*0.7;                 % threshold for preamble synchronization 

r_frmsync = conv(flip(preamble_code),r_tim);                   % signal synchronized by preamble code  

ind_frm = find(abs(r_frmsync) > thres);                        % indexies of training data(frame header)

frm_tick = zeros(1,length(r_tim));
frm_tick(ind_frm) = sign(r_frmsync(ind_frm));

figure(8)
subplot(3,1,1), stem(r_tim)                      % plot timing recovered signal
title('Timing recovered signal')
subplot(3,1,2), stem(r_frmsync)                  % plot synchronized signal
title('Synchronized signal by preamble')
subplot(3,1,3), stem(frm_tick)                   % plot frame ticker
title('Tick for header of frame')

% construct Equalizer
n = 16;                                         % number of taps for LMS       

f = zeros(n,1);                                 % initialize equalizer at 0

mu = .01;   delta = 4;                          % stepsize and delay delta        
m = preamble_len;

for i = n+1:m 
    rr = r_tim(i:-1:i-n+1);
    e = preamble_code(i-delta)-rr*f;
    f = f + mu*e*rr';
end

% Apply Equalizer

r_eql = filter(f, 1, r_tim);                    % output of channel
r_eql = r_eql(delta+1:end);

figure(9), 

plotspec(r_tim,Ts)
title('signal before Equalizer ')

figure(10), 

plotspec(r_eql,Ts)
title('signal after Equalizer ')


%% Decoder with Frame synchronization

r_msg = [];

len_frm = ind_frm(2)-ind_frm(1)-preamble_len;                             % frame length

for i = 1:length(ind_frm)-1
    r_msg = [r_msg, frm_tick(ind_frm(i))*pol_frm*r_eql(ind_frm(i)+1:ind_frm(i)+len_frm)];                % integrate the frame data                                                                            %     in the correlated signal (A & B) half of signal the peamble siignal has minus values  
end

len_lastfrm = len_frm;                                                      % length of last frame

if(len_frm+ind_frm(end)>length(r_eql))                                      % last frame is not full
    len_lastfrm = length(r_eql) - ind_frm(end);                             % update length of last frame
end

r_msg = [r_msg r_eql(ind_frm(end)+1:ind_frm(end)+len_lastfrm)];             % add last frame data to the msg

letter = quantalph(r_msg, [-3, -1, 1, 3])';                                 % quantize signal
output = pam2letters(letter)                                                % pam to letters
