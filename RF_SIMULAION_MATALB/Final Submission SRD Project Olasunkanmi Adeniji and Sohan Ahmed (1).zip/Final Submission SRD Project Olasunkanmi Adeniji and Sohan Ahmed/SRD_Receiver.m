% Project : Design a SRD M6 receiver to decode 3 Mystery signals
% Submitted to : Professor Dr. Volker Strumpen.
% Submitted by : Adeniji Olasunkanmi & Sohan Ahmed.
% Refence: Concept & Code from the Book and lecture (Software Receiver Design, and the SRD files)
%{ Workflow of the Receiver :
                         %  1. input the signal and transmitter parameters
                         %  2. Pass the signal to a LPF (Low Pass Filter) 
                         %  3. Downconvertion of the signal : 
                         
                            %  3.a. Check the Upsampling --> Bandpass filter as preprocessing also square nonlinearity
                            %  3.b. Estimate the carier 
                            %  3.c. Demodulate the signal (multiply the carrier with signal)
                            
                         %  4. Low Pass Filter
                         %  5. Pulse Match Filter 
                         %  6. Clock Recovery / Timing Recovery and Down Sampling  
                         %  7. Frame Synchronization (Corelation)
                         %  8. Equalize
                         %  9. Quantizer
                         %  10. Decode the signal 
%}

clc, clear, close all

%% Step 01: choose the signal by entering A, B or C || Define the perametrs from Transmitter Specifications

% User Input: 
dims = [1 50];
dlgtitle = 'Choose the mystery signal ';
prompt = {' Enter the mystery :  (A, B, C) '};
signal = inputdlg(prompt, dlgtitle, dims);

% Transmitter Specification with other calculated using variables: 

switch char(signal)
    
%Mystry Signal A
    case 'A'
        load mysteryA.mat
        SRRCLen = 5;            % SRRC length
        beta = 0.25;            % SRRC pulse-shape rolloff factor
        Tt = 9e-6;              % symbol period (sec)
        Fif = 1.88e6;           % intermediate frequency (Hz)
        Fs = 820e3;             % sampling frequency (Hz)       
        
        Ts = 1/Fs;              % time sampling (sec)
        f0 = Fif;
        th = 400;               % threshold for correlation
        delta = 0.1;            % delay for timeing recovery alg
        s = 1;                  % used for decoding
        delayspread = 4;        % delay delta for LMS 
        numtaps = 16;           % number of taps for LMS 

        
% bandpass filter parameters for mystery A
 while abs(f0-Fs) < f0                     
            f0 = abs(f0-Fs);
 end
            
        f3 = (2*f0/Fs)+0.2;
        f4 = (2*f0/Fs)+0.21;
        
        
%Mystry Signal B: 

    case 'B'
        load mysteryB.mat
        SRRCLen = 3;            % SRRC length
        beta = 0.35;            % SRRC pulse-shape rolloff factor
        Tt = 7.3e-6;              % symbol period (sec)
        Fif = 1.92e6;           % intermediate frequency (Hz)
        Fs = 680e3;             % sampling frequency (Hz)
        
        Ts = 1/Fs;              % time sampling (sec)
        f0 = Fif;
        th = 250;               % threshold for correlation
        s = -1;
        delta = 0.1;            % delay for timeing recovery alg
        delayspread = 4;        % delay delta for LMS 
        numtaps = 16;           % number of taps for LMS 

        % bandpass filter parameters for mystery B
        while abs(f0-Fs) < f0                     
            f0=abs(f0-Fs);
        end
        
       
        f3 = (2*f0/Fs)+0.24;
        f4 = (2*f0/Fs)+0.25;
  
%Mystry Signal C:

    case 'C'
        load mysteryC.mat
        SRRCLen = 4;            % SRRC length
        beta = 0.3;             % SRRC pulse-shape rolloff factor
        Tt = 8.2e-6;            % symbol period (sec)
        Fif = 2.4e6;            % intermediate frequency (Hz)
        Fs = 760e3;             % sampling frequency (Hz)       
        
        Ts = 1/Fs;              % time sampling (sec)
        f0 = Fif;
        th = 250;               % threshold for correlation
        delta = 0.009;          % delay for timeing recovery alg
        delayspread = 2;        % delay delta for LMS    
        numtaps = 13;           % number of taps for LMS 
        s = 1;
        
        % bandpass filter parameters for mystery C
        while abs(f0-Fs) < f0                     
            f0=abs(f0-Fs);
        end
        
      
        f3 = (2*f0/Fs)+0.2;
        f4 = (2*f0/Fs)+0.21;

end



SigLen = length(r);             % length of signal(r is the analog received signal)

M = Fs*Tt;                      % upsampling ratio 

% plot the received signal
figure(1), plotspec(r, Ts), 
title('Received  signal')

%% Step 02:  LPF to remove high frequency 

h = firpm(500,[0 f3 f4 1],[ 1 1 0 0]);                  % LPF design
x_if = filtfilt(h,1,r);                     % LP filter 

                                                                                                    % % plot the frequency response of LPF
                                                                                                    % figure(12) 
                                                                                                    % [h,w] = freqz(h);
                                                                                                    % plot(w/2/pi*Fs, 20*log10(abs(h)))
                                                                                                    % xlabel('frequency'), ylabel('magnitude (dB)')
% plot the frequency response of LPF 
figure (2), 
plotspec(x_if, Ts), 
title('Signal after LPF')

%% Step 03: downconversion

%carrier estimate 

carrier = CarrierEST(x_if,f0,Fs)';

% Demodulate the signal
x_BB = x_if .* carrier/2;  %



figure(4 ), plotspec(carrier, Ts), 
title('Estimated Carrier Frequency')
figure(5), plotspec(x_BB, Ts)
title('Downconverted to Baseband siganl')

%% Step 04 : LPF

h = firpm(500,[0 f3-.28 f4-.28 1],[1 1 0 0]);                  

x_LPF = filtfilt(h, 1, x_BB);           % executing the LPF

figure(6), plotspec(x_LPF, Ts)
title('signal after LPF')

%% Step 05:  matched filter

matchfilt = srrc(SRRCLen, beta, M, 0);          % Pulse normalization
x_match = filtfilt(matchfilt, 1, x_LPF);        % filter the pulse shape

figure(7), plotspec(x_match, Ts)                                                            
title('signal after Matched filter')



%% Step 06: Downsampling with OPM Time/Clock recovery

% Initialize parameters            
len = SigLen;                                 % Length of the received Signal                      
DwnSmpSig = zeros(1,ceil(len/M));             %initialize down smapled signal 

% algorithm parameters
tnow = SRRCLen*M+1; tau=0;                      % initialized Variables
tausave = zeros(1,len); tausave(1)=tau; i=0;                            
mu = 0.1;                                                     %stepsize

while tnow < len-SRRCLen*M                     % run iteration
  i=i+1;
  DwnSmpSig(i) = interpsinc(x_match, tnow+tau, SRRCLen);           % interpolated value at tnow+tau
  x_deltap = interpsinc(x_match, tnow+tau+delta, SRRCLen);      % get value to the right
  x_deltam = interpsinc(x_match, tnow+tau-delta, SRRCLen);      % get value to the left
  dx = x_deltap - x_deltam;                               % calculate numerical derivative
  qx = quantalph(DwnSmpSig(i),[-3,-1,1,3]);                  % quantize to nearest 4-PAM symbol
  tau = tau + mu*dx*(qx-DwnSmpSig(i));                       % alg update
  tnow = tnow + M; 
  tausave(i)=tau;                                      % save for plotting
end

% plot results
figure(8), subplot(2,1,1), plot(DwnSmpSig(1:i-2),'b.')        % plot constellation diagram
title('constellation diagram');
ylabel('estimated symbol values')
subplot(2,1,2), plot(tausave(1:i-2))            % plot trajectory of tau
ylabel('offset estimates'), xlabel('iterations')

%% Step 07: frame synchronization 

preamble = letters2pam('A0Oh well whatever Nevermind');
framlent = 512;
prelent = length(preamble);   
SynSig = filter(flip(preamble),1,DwnSmpSig);                % correlation between peamble with downsampled Signal
ind = find(abs(SynSig) > th);                % location of largest correlation...

figure(9)
subplot(3,1,1), stem(preamble)              % plot header
title('Header')
subplot(3,1,2), stem(DwnSmpSig)                  % plot data sequence
title('Data with embedded header')
subplot(3,1,3), stem(SynSig)                   % plot correlation
title('Correlation of header with data')


%% Step 8:  Applying Equalizer :  LMS Equalizer

mu = .01;                        % stepsize 

f = zeros(numtaps,1);              % initialize equalizer at 0
timer1=0;
   
    for timer1 = numtaps+1:prelent 
        rr = DwnSmpSig(timer1:-1:timer1-numtaps+1);
        e = preamble(timer1-delayspread) - rr*f;
        f = f + mu*e*rr';
    end

%Update The Equalizer to the signal
x_EQL = filter(f, 1, DwnSmpSig);
x_EQL = x_EQL(delayspread+1:end);

figure(10), 
subplot(3,1,3), plot(x_EQL,'b.')        % plot constellation diagram
title('the soft decesion')

plotspec(x_EQL, Ts)
title('signal after Equalizer ')


%% Step 09: Quantize and final decoding

x_decode = [];
for i = 1:length(ind)-1
    x_decode = [x_decode s*sign(SynSig(ind(i)))*x_EQL(ind(i)+1:ind(i+1)-prelent)];     % removing the header jumping over the ind and final signal will be just the text components ; 
                                                                                     %     in the correlated signal (A & B) half of signal the peamble siignal has minus values  
end

x_decode = [x_decode -x_EQL(ind(end)+1:end-prelent)];                                % Until The last frame decoding

%Quantise  and ready to decode
letter = quantalph(x_decode, [-3, -1, 1, 3])';                                          % Quantized to alphabets
output = pam2letters(letter)                                                           % Reconstruct the message

% writematrix(output, 'output')